========================================================================
g4j - GMail API For Java v0.3.19
========================================================================

GMailer API for Java (g4j) is set of API that allows Java programmer to communicate to GMail. With G4J programmers can made Java based application that based on huge storage of GMail.

An Email application, GMailer for Java is also built to demonstrate the usage of the API. It is planned to include minimalist email capabilities such as browse, search, read, send mail and download files.

================
Release Notes 0.3.19
================

As suggested by Bevalentin, URL constants is extracted into static.properties, the contact list bug is fixed as well.

================
Release Notes 0.3.18
================

Add support for forwarding attachment
Fix url to download attachment

================
Release Notes 0.3.17
================

Fixing the change in gmail URL

================
Release Notes 0.3.14
================

Another fix that adapt the change in gmail. This version comes with a ant build file (build.xml), it simplify the building, packaging and testing task.

You would need Java Runtime Environment (JRE) version 1.4 to run this software, download it in http:// java.sun.com/

To use the software, run g4j.bat on Windows or g4j.sh on Unix. To Use the library include the g4j-lib.jar in your programs. You would need the g4j-deps package (separate download) to build the software.

This program is developed mainly in Windows XP & 2000, it have not been tested on other platforms. If you encounter any problem please post a message in project support page.

==========
Change Log
==========
G4J, Set of API that allows Java programmer to communicate to GMail.
Version 0.3.14 - (17-Dec-2004) 
Fixed: Fix for new gmail protocol; Correctly save cookies.

Version 0.3.13 - (2-Dec-2004) 
Fixed: Fix new gmail protocol; Refactor some codes

Version 0.3.11 - (15-Oct-2004) 
Fixed: Fix new gmail contact interface, GMContact structure changed, new function GMConnector.getContact() replace old requestContact()

Version 0.3.10 - (7-Oct-2004) 
Added: GMConnector.fetchOriginalMail(String id) added, download original mail source from gmail
Added: Preliminary support of send mail.
Bugfix: "Drafts" mail now being prased correctly

Version 0.3.9 - (5-Oct-2004) 
Update: GMail new mailbox "Drafts" supported

Version 0.3.4 - (27-Sep-2004) 
Features: With multi-threaded http client, single connector can send multiple request at the same time
Features: Parse the java script redirection in request()

Version 0.3.3 - (22-Sep-2004) 
Bug Fix: Correctly parse escaped characters such as ' " < > \n and \r; 
Features: Implement missing "message body" packets in entries in conversation (GMConversationEntry)

Version 0.3.2
(18-Sep-2004) Refactored code

Version 0.3
(17-Sep-2004) API to download conversation and open attachment as InputStream 

Version 0.2
API to retrive threads from mailbox/label and search message 

Version 0.1
API to connect to GMail 

GMailer for Java, Minimalist Email client that retive email from Gmail. 

Features: Check, read and search email, monitor mailbox peridocally, minimized to SysTray in Windows and Linux KDE3, list email in mailbox. 
Version 0.3.13
(2-Dec-2004) 
Added: Selectable e-mail alert
Fixed: Fix new gmail protocol

Version 0.3.4
(16-Oct-2004)
Bugfix: when a message opened it was scrolled to bottom
Added: Open browser, like the original gmail notifier from google

Version 0.3.3
(15-Oct-2004)
Added: Search messages
Bugfix: Show offline message list correctly
Bugfix: Click the sys tray icon before the program completely loaded, the program would popup and behave strangly
Enhance: new toolbar buttons for better looks, across different platform/LAF

Version 0.3.2
(7-Oct-2004)
Added: Debug console
Bugfix: Fix the problem that when exit without login, the software might not exiting properly.
Bugfix: "Drafts" mail now being displayed correctly

Version 0.3.1
(5-Oct-2004) 
Update: GMail new mailbox "Drafts" supported

Version 0.3
(3-Oct-2004)
- BUGFIX: Reformat the message pane so that user can use mouse wheel to scroll message content.
- ENHANCEMENT: improved performance to apply a LAF

Version 0.3-pre3
(1-Oct-2004)
- FEATURES: Look and Feel chooser avaliable in option, features JGoodies Look and feel and theme
- ENHANCEMENT: Show or hide message content using a better method, preformance improved
- BUGFIX: Correctly disable menu items/toolbar buttons

Version 0.3-pre2
(27-Sep-2004) 
- If a message is already downloaded, now GMailer read message from local disk instead of download again
- With multi-threaded g4j api and rewritten usage of threads, the general performance is improved
- Correct the tooltips of the systray icon

Version 0.3-pre1
(26-Sep-2004) 
- Save data to local drive, the programs now can work offline to read downloaded message.
- Rewrite UI, now looks more comfortable. Add serveral icons, mostly come from Eclipse, others are draw by myself.

Version 0.2.1
(22-Sep-2004) Open message body (partly)

Version 0.2 
(18-Sep-2004) Added support of minimized to SysTray in Windows and KDE3; Support of auto connect and check message;

Version 0.1
(17-Sep-2004) This version connect to GMail and listing mailboxes. Searching, Viewing email and download attachment would be included in future release. 

==========
Todo
==========
G4J
- API to send mail
- API to search mail by contact
- API to do others actions

GMailer4j
- Tabbed Conversation/Messages
- Open message in browser
- Open conversation with navigation through threads
- Clickable links in message panel

===============
Acknowledgement
===============
This project is inspried and motivated by GMailer for PHP and Gmail Agent API , their great works make me want to have an Java Implementation of their kind. Their open sources also made the understanding of GMail's protocol much easier, Thank You!

This project use :
 - Apache Jakarta Commons HTTPClient to access web page
 - Apache Jakrata Commons Codec to decode email
 - SysTray4j for Java to make the System Tray tricks
 - SIXBS (Simple XML Bean Serialization) for saving document in XML
 - JGoodies for better UI looks
 - Concurrent Utilities from Doug Lea ( http://gee.cs.oswego.edu/dl/classes/EDU/oswego/cs/dl/util/concurrent/intro.html )
 - Eclipse for their nice icons

====================
Support and Contribution
====================
If you have any problem, opinion, or software that built on g4j, please visit sourceforge home page at http://sourceforge.net/projects/g4j/

