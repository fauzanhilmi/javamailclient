#!/bin/sh

java -Djava.util.logging.config.file=logging.properties -cp g4j-lib.jar:g4j.jar siuying.gm.app.gmailer4j.GMailer4j &